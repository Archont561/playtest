my $expected_version = "0.48";
print("import: Capture::Tiny\n");
use Capture::Tiny;

if (defined Capture::Tiny->VERSION) {
	my $given_version = Capture::Tiny->VERSION;
	$given_version =~ s/0+$//;
	die('Expected version ' . $expected_version . ' but found ' . $given_version) unless ($expected_version eq $given_version);
	print('	using version ' . Capture::Tiny->VERSION . '
');

}
